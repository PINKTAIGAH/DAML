To run the python analyser, run the following command in the <path/to>/week-14-checkpoint/ directory:

python3 bin/compute_energies.py

The image for question 1 can be found in the <path/to>/week-14-checkpoint/images directory
